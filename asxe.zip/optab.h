//Class: CS530 - Systems Programming (Spring 2024)
//Assignment: Project #2 (SIC/XE Two-Pass Assembler)
//Filename: optab.h (Header file)

#ifndef OPTAB_H
#define OPTAB_H

#include <string>
#include <unordered_map>
#include <utility>

//class to create an operation code table
class Optab {
private:
	std::unordered_map<std::string, std::pair<int, int>> optab;		//declare hash table variable to store optab elements {mnemonic, {opcode, format}}

public:
	//constructor
	Optab ();

	//member functions
	void printOptab ();							//function to print out operation code table; SOLELY FOR TESTING
	void printOpcode (const std::string& mnemonic);				//function to print out the hex opcode of the given mnemonic instruction
	std::unordered_map<std::string, std::pair<int, int>> getOptab() const;	//function to retrieve the optab and store it in a hash table object variable
	int getFormat(const std::string& mnemonic);
	void printForLoop ();
};

#endif // OPTAB_H
