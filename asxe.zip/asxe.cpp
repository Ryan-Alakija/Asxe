//Class: CS530 - Systems Programming (Spring 2024)
//Assignment: Project #2 (SIC/XE Two-Pass Assembler)
//Filename: asxe.cpp (main program)

#include "optab.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <unordered_map>
#include <map>
#include <utility>
#include <vector>
#include <algorithm>
#include <iomanip>
#include <stdexcept>
#include <cstdlib>

//define struct for literal table
struct Littab {
	std::string name;					//name of literal
	char type;						//'X' (hex) or 'C' (char)
	std::string operandVal;					//operand of literal
	std::string address; 					//location of literal
	int length;						//length of literal

	//define equality operator for Littab, needed for comparison functions
	bool operator==(const Littab& other) const {
		return name==other.name && type==other.type && operandVal==other.operandVal && address==other.address && length==other.length;
	}
};

//checks if a file is open and outputs an error messsage if not
//also mentions the file in question, hence the string parameter
void checkIfFileOpen (std::ios& file, const std::string& fileType) {
	if (!file) {
		std::cerr << "Error: There was a problem with opening up the ";		//print out error message if file did not open
		std::cerr << fileType << std::endl;					//specify the kind of file it is (ex: source file)
		exit(1);								//exit the program with error indicator
	}
}

//write a hexadecimal number and use your own parameters to format it
//in this program, string and int are the two most commonly used data types for
//the <typename T> template class
template<typename T>
std::string writeHex (int w, char fill, const T& val) {
	std::ostringstream oss;								//declare output string stream object to write a string into
	std::string hex;								//declare temporary string variable to store the hex representation of the value
	int l;										//declare temporary int variable to store length of string

	oss << std::setw(w) << std::setfill(fill) << std::right << std::hex << val;	//write the hex representation of the value to the output string stream object 
	hex = oss.str();								//store the hex representation of the given value in the other string variable
	l = hex.length();								//get the length of the other string variable

	oss << std::resetiosflags(std::ios_base::basefield);				//reset the hex formatting flag of the output string stream
	oss.str("");									//set the string value in the output stream string object to empty

	//if the size of the string itself is greater than the given width
	//though if the width is 0, just print it out however long it needs to be
	if (w > 0 && l > w)
		hex = hex.substr(l - w, w);						//truncate the string to the given width and its rightmost values

	oss << std::setw(w) << std::setfill(fill) << std::right << hex;			//print out the formatted hex value 
	oss << std::resetiosflags(std::ios::adjustfield | std::ios_base::basefield);	//reset all formatting flags of the output stream right after
	return oss.str();								//return the output string object
}

//check if the line contains the start directive and update the component values
bool hasStart (const std::string& line, std::string& label, std::string& opcode, std::string& operand) {
	std::istringstream statement(line);					//declare input string stream object to read in words to a string variable
	std::string word, prevWord;						//declare a string variable to store the word, then another one to store the word previously read
	while (statement >> word) {
		if (word == "START") {
			label = prevWord;					//check if there is a label before the START directive
			opcode = word;						//store value of word ("START") in opcode
			statement >> word;					//read the next word of the line
			operand = word;						//...then store it in operand
			return true;						//return the boolean value as true
		}
		prevWord = word;						//assign value of word to prevWord to update the label
	}
	return false;								//return the boolean value as false after reading the whole line
}

//check if line is a comment line
bool isCommentLine (const std::string& line) {
	char firstChar;						//declare char variable to store a single given char value in a string
	bool comment;						//declare boolean variable that will return the result

	std::istringstream words(line);				//declare an input string stream object to read words or characters that are not white space
	std::string firstWord;					//declare a string variable to store the very first word

	words >> firstWord;					//read the first word into the string variable

	firstChar = firstWord[0];				//extract the very first index char of the word
	//if the line starts with '.' or
	//if it's just an empty space
	if (firstChar == '.' || line == "")
		comment = true;					//if the first character is a period, then the line is a comment line
	else
		comment = false;
	return comment;
}

//read the line and get the values of the four different components of each statement: location, label, opcode, and operand
//note: if assembler is on pass 1, assign the location parameter to the following verbatim: "On Pass 1"
//this way, I don't need to make a brand new function just for pass 2 when i can just reuse this one
void getComponents (int& i, const std::string& line, std::string& location, std::string& label, std::string& opcode, std::string& operand, char& prefix) {
	int temp;							//declare temporary variable just to briefly store a value
	//int compThreshold1;						//declare int variable to store threshold for i
	//int compThreshold2;						//declare another int variable for same reason as above, we need these to change them accordingly
	const int NUM_COMPS = 4;					//there are up to four different components of a source instruction: location, label, opcode, and operand
	std::string comps[NUM_COMPS];					//declare array to store up to three different components of an instruction
									//comps[0] = label, comps[1] = opcode, comps[2] = operand
	std::istringstream statement(line);				//declare an input string stream object to read each word from the line
	std::string word;						//declare another string variable to extract each word from the object
	
	i = 0;
	//compThreshold1 = 3;						//initialize the first threshold to be 3
	//compThreshold2 = 2;						//initialize the second threshold to be 2
	if (location == "On Pass 1") {
		comps[0] = location;
		i++;
	}
	while (statement >> word && i < 4) {
		comps[i] = word;					//assign each word to one of the array locations
		i++;							//increment i each time to increment through the array
	}
	if (location != "On Pass 1")
		location = comps[0];					//assign location to comps[0] if assembler is on pass 2
	if (i == 4) {
		label = comps[1];					//label is the first word of the instruction, though is only included if there are three total words in the line
		opcode = comps[2];					//opcode is the second word of the instruction
		operand = comps[3];					//operand is the final word of the instruction
	}
	else if (i == 3) {
		if (comps[1] == "*") {
			label = comps[1];				//the * prefix in the labels section signifies a comment instruction
			opcode = comps[2];				//this makes things a bit different than usual
			operand = " ";
		}
		else {
			label = " ";
			opcode = comps[1];				//if there is not a label, there are only two components; opcode is the first word of the instruction
			operand = comps[2];				//operand is the second word of the instruction
		}
	}
	//if i < 3
	else {
		label = " ";
		opcode = comps[1];					//in VERY rare cases, there is only an opcode mnemonic instruction and nothing else (Ex: RSUB)
		operand = " ";
	}

	//in pass 2, the statement if location != "On Pass 1" assigns
	//"END" to location value, so this is the awkward workaround
	if (location == "END") {
		location = " ";
		label = " ";
		operand = opcode;					//what is supposed to be the operand got assigned to opcode, so operand is being assigned before opcode here
		opcode = "END";						//assign "END" to opcode
	}

	prefix = opcode[0];						//get the very first character of the opcode string
	temp = opcode.length();						//get the length of the opcode string and store it in the temporary variable

	//if operand is only 1 char long, then it can lead to a runtime
	//error with opcode.substr(1), hence why there is also a
	//condition to check if the lenght of opcode is greater than 1
	if (temp > 1 && (prefix < 'A' || prefix > 'Z'))			//this if condition signifies that the first character of opcode is a prefix
		opcode = opcode.substr(1);				//hence why we need to get rid of the prefix from the opcode variable
	else								//this is important when we run the opcode string through the opcode table
		prefix = ' ';						//assign null character to prefix char variable if there is not a prefix preceeding the opcode instruction

	//note: a seperate function deals with prefixes for operand
	//values, this one just sticks to opcode prefixes
	
	//TESTING: print out which values are being assigned to which variables
	//std::cout << "Location: \"" << location << "\"" << std::endl;
	//std::cout << "Label: \"" << label << "\"" << std::endl;
	//std::cout << "Opcode: \"" << opcode << "\"" << std::endl;
	//std::cout << "Operand: \"" << operand << "\"" << std::endl;
}

//check if the operand is a literal
bool checkIfLiteral (std::string operand) {
	char prefix;							//declare a prefix value to store prefixes of the operand
									//note: we do not need to extract the prefix from the operand until pass 2, hence why we do not have the prefix value
									//from the pass 1 method as a parameter to update it, unlike when we are manipulating get components above
	bool literal;							//declare variable to determine if the operand is a literal or not

	prefix = operand[0];						//extract the first char from the operand string and store it in prefix variable
	if (prefix == '=')
		literal = true;						//the '=' prefix signifies a literal
	else
		literal = false;					//return false otherwise
	return literal;
}

//get the name, length and operand of the literal; location will be taken care of separately
//note: ONLY run this after checking if the operand is a literal through the '=' prefix
void getLiteralVals (const std::string& operand, std::string& name, char& type, int& length, std::string& operandVal) {

	size_t start;							//declare a size_t variable to store the start index of a string
	size_t end;							//declare another size_t variable to store the end index

	std::ostringstream op;						//declare output string stream object to write operand to

	start = operand.find("'") + 1;					//find the first single quote, this is where the string of the literal starts
	end = operand.find("'", start);					//find the second single quote, this is where the string of the literal ends
	//note: the second parameter of the find() function for
	//strings is supposed to represent the starting position the
	//function starts the search from, hence why in order to find
	//the second single quote, the start position is whatever the
	//established start index is (one after the first quote)

	//assign the extracted literal to the name parameter variable
	name = operand.substr(start, end - start);			//extract the literal with the substr() method, first parameter is the start index, second parameter is the length of the string hence (end - start)

	type = operand[1];						//get the literal type (either C or X)
	length = name.length();						//get the length of the literal and assign it to the length parameter variable

	if (type == 'C') {						//the 'C' literal type signifies the value is in chars
		//no need to alter the length
		//loop through each char in the literal
		for (char c : name) {
			int i = (int) c;				//convert char to an int first so we can represent it as a hex value
			op << writeHex (2, '0', i);			//write to the output string stream object as the hex value of the char 
		}
		operandVal = op.str();					//convert output string stream object to string and assign it to operandVal
	}
	else if (type == 'X') {						//the 'X' literal type signifies the value is in hex
		length /= 2;						//two hex values = 1 byte = 1 locCtr incrementation

		operandVal = name;					//assign the name to the operand value
	}
	else {
		std::cerr << "Error: Invalid literal" << std::endl;	//print out an error message if the literal type is anything other than 'C' or 'X'
		exit(1);						//terminate program with error indicator
	}
	
}

//mainly for EQU directive statements, check if there is is an arithmetic
//symbol in the operand (+, -, *, /), implying the use of 'symbol
//arithmetic', return the operand if found
char checkForOperator (const std::string& operand, size_t& opInd) {
	char op;							//declare a char variable to get the 
	size_t tempInd;							//declare a temporary size_t variable to store the operator indexes, the index of the found operator will ultimately be stored in opInd
	//create an array of the operators to loop through
	const int NUM_SYMS = 4;						//declare the number of arithmetic symbols we are 
	char operators[NUM_SYMS] = {'+', '-', '*', '/'};		//declare an array with the given number of arithmetic symbols

	//loop through array
	for (int i = 0; i < NUM_SYMS; i++) {
		//op = operators[i];					//
		tempInd = operand.find(operators[i]);			//search for operator in string
		//std::cout << operators[i] << " opInd: " << opInd << std::endl;
		//std::cout << "Operand being searched for: " << operators[i] << std::endl;
		//if operator exists
		if (tempInd != std::string::npos) {
			op = operators[i];				//
			opInd = tempInd;				//
		}
	}
	return op;							//return the char value either as a found operator or null
}

//write to intermediate file
//note: needs to be called multiple times throughout pass 1 algorithm, hence being a separate method
void writeIntFile (int loc, std::string label, std::string opcode, std::string operand, std::ofstream& intfs, char pre) {
	if (opcode != "END" && opcode != "LTORG") {
		intfs << std::left << std::setw(16) << writeHex (6, '0', loc);
		intfs << std::setw(16) << label << std::setw(16) << pre + opcode;	//write line to intermediate file
		//std::cout << writeHex (4, '0', loc) << "\t\t" << label << "\t\t";
		intfs << std::setw(16) << operand << std::endl;				//(location + original source file line)
		//std::cout << opcode << "\t\t" << operand << std::endl;
	}
	//we need to modify the formatting a bit for END and LTORG lines
	else {
		intfs << std::left << std::setw(32) << " " << std::setw(16) << pre + opcode;
		intfs << std::setw(16) << operand << std::endl;				//don't include location on the end line
	}
	intfs << std::resetiosflags(std::ios::adjustfield | std::ios_base::basefield);	//reset all formatting flags of the output stream
}

//write to symtab file
void writeSymTabFile (const std::vector<std::map<std::string, std::string>>& symtab, std::ofstream& symfs, std::string csect, int length, int startaddr) {
	//print out the title
	symfs << "SYMBOL TABLE\n" << std::endl;
	//print out the categories
	symfs << std::left << std::setw(12) << "Csect" << std::setw(12) << "Symbol" << std::setw(12) << "Value";
	symfs << std::setw(12) << "LENGTH" << std::setw(12) << "Flags" << std::endl;
	//print out the first row with the starting C-section, the start address, and length
	symfs << std::setw(24) << csect << std::setw(12) << writeHex (6, '0', startaddr);
	symfs << std::setw(12) << writeHex (6, '0', length) << std::endl;
	//loop through the vector-map with a nested for-range loop
	//and print out each symbol and location accordingly
	for (const auto& sym : symtab) {
		for (const auto& symIt : sym) {
			symfs << std::setw(12) << " " << std::setw(12) << symIt.first << std::setw(24) << symIt.second << "R" << std::endl;
		}
	}
}

//write to littab file
void writeLitTabFile (std::vector<Littab>& littab, std::ofstream& litfs) {
	//print out the title
	litfs << "LITERAL TABLE\n" << std::endl;
	//print out the categories
	litfs << std::left << std::setw(12) << "Name" << std::setw(12) << "Type" << std::setw(12) << "Operand";
	litfs << std::setw(12) << "Address" << std::setw(12) << "Length" << std::endl;
	//loop through the vector with a for-range loop
	//and print out each category of the struct variable accordingly
	for (const auto& lit : littab) {
		std::string opLowerCase;						//declare a temporary string variable to store the lowercase value of each literal, just to keep things consistent

		opLowerCase = lit.operandVal;						//store the operand value of the literal into the temporary string variable
		//convert the value of the temporary string variable to lowercase
		std::transform(opLowerCase.begin(), opLowerCase.end(), opLowerCase.begin(),
			[](unsigned char c) { return std::tolower(c); });
		//print out the categories of the struct variable, with opLowerCase replacing lit.operandVal
		litfs << std::setw(12) << lit.name << std::setw(12) << lit.type << std::setw(12) << opLowerCase;
		litfs << std::setw(12) << lit.address << std::setw(12) << lit.length << std::endl;
	}
}

//check if string represents an int value or not
//namely used for operand during the second pass
//also used to extract the operand prefix and index register specifier
bool isAnInteger (std::string& operand, char& prefix, char& irs) {
	int temp;									//declare temp variable to briefly store the length of operand string
	bool isInt;									//declare boolean variable to store result that will be returned
	size_t commaIndex;								//declare boolean variable to store an index of any potential commas in operand

	prefix = operand[0];								//get the first letter of the operand string
	temp = operand.length();							//get length of operand string
	
	//some methods to extract the operand value

	//if the operand is just one char, then it can lead to
	//a runtime error with operand.substr(1)
	if (temp > 1 && (prefix < 'A' || prefix > 'Z') && (prefix < '0' || prefix > '9'))
		operand = operand.substr(1);						//extract the prefix from operand if it is anything besides a letter
	else
		prefix = ' ';								//there is no prefix, so make the prefix char value null
	//std::cout << "First operand check: " << operand << std::endl;
	commaIndex = operand.find(',');							//get the index of potential comma in operand string
	//if comma is found
	if (commaIndex != std::string::npos) {
		irs = operand.at(commaIndex + 1);					//extract the "X" after the comma and store into the index register specifier
		operand = operand.substr(0, commaIndex);				//extract the string that goes up to the comma and update the operand string variable with it accordingly
	}
	//else
	//	irs = '\0';								//there is not index register specifier, so make the char value null
	//std::cout << "Second operand check: " << operand << std::endl;			//test that these string manipulations algorithms work in extracting the operand value
	
	//implement a try-catch block to catch an error if converting the string
	//to an int value does not work
	try {
		std::stoi(operand);							//convert string to int
		isInt = true;								//assign boolean to true if there is no exception to be found
		//std::cout << "Third operand check: " << operand << std::endl;
	}
	catch (...) {
		isInt = false;								//return false if an exception arises from trying to convert the string
	}
	return isInt;									//return the result
}

//assemble the machine instruction accordingly and return it as a string variable
std::string assembleInstruction (Optab& optab, std::unordered_map<std::string, std::pair<int, int>>::iterator& opIt, int& X, int& B, int& PC, bool isInt, bool base, std::string location, std::string operand, int I, int TA, char pre1, char pre2, char irs) {

	//X = index register
	//B = base register
	//PC = PC register
	//I = increment value that determines the number of components in an instruction
	//TA = target address
	//pre1 = prefix for opcode
	//pre2 = prefix for operand
	//irs = index register specifier

	int disp;									//declare int variable to store the displacement value, based off the target address
	int loc;									//declare int variable to store the int value of the given location
	//bool isInt;									//declare boolean variable to store result of whether the operand is a constant int value or not

	std::ostringstream oss;								//declare output string stream object to write the contents of the assembled instruction to

	//declare variables to store values of the opcode instruction
	std::string mnemonic;								//declare string variable to store the mnemonic instruction
	int opcode;									//declare int variable to store the opcode of the mnemonic instruction
	int format;									//declare int variable to store the format of the mnemonic instruction

	//declare boolean variables for each flag
	bool n;										//the n flag, signifies indirect addressing by itself
	bool i;										//the i flag, signifies immediate addressing by itself
	bool x;										//the x flag, signifies index addressing
	bool b;										//the b flag, signifies base-relative addressing
	bool p;										//the p flag, signifies PC-relative addressing
	bool e;										//the e flag, signifies an extended instruction (format 3 => format 4)

	//const int REG_A = 0;
	//const int REG_X = 1;
	//const int REG_L = 2;
	//const int REG_B = 3;
	//const int REG_S = 4;
	//const int REG_T = 5;
	//const int REG_F = 6;
	//const int REG_PC = 8;
	//const int REG_SW = 9;

	std::map<char, int> regVals;							//declare a map to store all the different SIC/XE registers and their respective numbers
	std::map<char, int>::iterator regIt;						//declare an iteratior for regVals

	loc = std::stoi(location, nullptr, 16);						//convert location from string hex representation to integer and store in the declared int value

	mnemonic = opIt->first;								//extract mnemonic value out of the optab iterator and assign it accordingly
	opcode = opIt->second.first;							//extract opcode value out of the optab iterator and assign it accordingly
	format = opIt->second.second;							//extract format value out of the optab iterator and assign it accordingly

	n = false, i = false, x = false, b = false, p = false, e = false;		//set all flags to false (0) by default

	//establish register numbers for registers that get implemented in instructions
	//starting with the SIC registers
	regVals ['A'] = 0;								//the A register number is 0
	regVals ['X'] = 1;								//the X register number is 1
	regVals ['L'] = 2;								//the L register number is 2
	//now for the SIC/XE registers
	regVals ['S'] = 4;								//the S register number is 4
	regVals ['T'] = 5;								//the T register number is 5
	regVals ['F'] = 6;								//the F register number is 6

	if (format == 3) {

		//lets first increment the opcode accordingly
		//we need to manipulate the value of the second 'hex-nibble'
		//which contains the n & i flags in the last two binary bits		

		//immediate addressing
		if (pre2 == '#') {
			i = true;							//set just the i flag to true (1)
			opcode += 0x1;							//increment opcode by 1 (AKA 01 in binary)
		}
		//indirect addressing
		else if (pre2 == '@') {
			n = true;							//set just the n flag to true (1)
			opcode += 0x2;							//increment opcode by 2 (AKA 10 in binary)
		}
		//simple addressing
		else {
			n = true, i = true;						//set both the n and i flags to true (1)
			opcode += 0x3;							//increment opcode by 3 (AKA 11 in binary)
		}

		oss << writeHex (2, '0', opcode);					//write the opcode instruction to the output string stream object

		//next, we need to determine the value of the third nibble
		//which consists of the x,b,p & e flags

		const int MIN_ADDR = -0x800;						//declare a constant variable for the minimum threshold of the displacement value (-2048)
		const int MAX_ADDR_PC = 0x7ff;						//declare a constant variable for the maximum threshold for a PC-relative addressing instruction (2047)
		const int MAX_THREE_BYTE_ADDR = 0xfff;					//declare a constant variable for the maximum 3-byte address (4095)
		const int MAX_LOCATION = 0x100000;					//declare a constant variable for the the maximum memory location that can exist in a SIC/XE program

		int thirdNibble;							//declare temporary int variable to store the value of the third nibble
		
		thirdNibble = 0x0;							//initialize value of thirdNibble to 0
		disp = TA - loc;							//temporarily store the distance between the target address and the current location of the instruction, in the displacement variable

		//extended (format 4) instruction
		if (pre1 == '+') {
			e = true;							//set the e flag to true
			thirdNibble += 0x1;						//increment thirdNibble by 1 (AKA 0001 in binary)
		}
		//if the operand is a constant int value or
		//if the instruction has only one component
		//two other cases where we don't use relative addressing
		else if (isInt || I < 3) {}
		//note: the absense of a '+' prefix does not ALWAYS equate to
		//the instruction being 'non-extended'
		//if the displacement is more than 3 bytes long,
		//base-relative addressing is usually the default
		//however, if there is no instruction that sets the B-register
		//to any value besides 0, we will need to make the instruction
		//an extended instruction
		else if (std::abs(disp) > MAX_THREE_BYTE_ADDR) {
			//if base register is set to a select value besides 0
			if (base) {
				b = true;						//set the b flag to true
				thirdNibble += 0x4;					//increment thirdNibble by 4 (AKA 0100 in binary)
			}
			//if there is not a base register value being set
			//this along with a displacement value above 3 bytes
			//both point towards an 'implicit extended instruction'
			else {
				e = true;						//set e flag to true
				thirdNibble += 0x1;					//increment thirdNibble by 1 (AKA 0001 in binary)
			}
		}
		else if (std::abs(disp) > MAX_ADDR_PC && base) {
			b = true;							//set the b flag to true
			thirdNibble += 0x4;						//increment thirdNibble by 4 (AKA 0100 in binary)
		}
		//any instruction that doesn't fit the above conditions
		//will use PC-relative addressing
		else {
			p = true;							//set the p flag to true
			thirdNibble += 0x2;						//increment thirdNibble by 2 (AKA 0010 in binary)
		}

		//implement separate if statement to determine if the displacement
		//is at a valid range, we can use abs() so we can do just one comparison
		if (std::abs(disp) > MAX_LOCATION) {
			std::cerr << "Error: Displacement for " << operand << " is ";
			std::cerr << "out of bounds (" << disp << ")" << std::endl;	//output an error message (out of bounds)
			std::cerr << "Must be between " << MIN_ADDR << " and ";
			std::cerr << MAX_LOCATION << std::endl;				//display the required range for displacement
			exit(1);							//terminate the program with an error indicator
		}

		//index addressing
		if (irs != '\0') {
			x = true;							//set the x flag to true
			thirdNibble += 8;						//increment thirdNibble by 8 (AKA 1000 in binary)
		}
		
		oss << writeHex (1, '0', thirdNibble);					//write the third nibble to the output string stream object

		//find the value of the displacement
		//(the last few nibbles of the instruction)

		//no need to alter the target address
		//based on anything related to the n or i bits
		if (n == true || i == true)
			disp = TA;							//just set the displacement as the target address

		//if x flag is set to true
		if (x)
			disp = TA - X;							//set the displacement as the difference between the target address and the index register value

		//if b flag is set to true
		if (b)
			disp = TA - B;							//set the displacement as the difference between the target address and the base register value
		//if p flag is set to true
		else if (p) {
			//since p flags are just for format 3/4 instructions, it is
			//only of of these two values we increment the register by
			PC = loc + 3;							//increment the program counter by 3 from whatever the current location of the instruction is
			if (e)
				PC += 1;						//increment by 1 extra if an extended instruction
			disp = TA - PC;							//set the target address as the difference between the actual target address and the program counter value
		}
		//nothing needed for else-statemnt, it's just here to cap off
		//the if-else block
		else {}
		//note: between b and p, only one can be set to true
		//technically, you COULD set both of them to be true
		//but it would be extremely unconventional
		//so I would like to avoid that for now

		//if the e-bit is set to true
		if (e)
			oss << writeHex (5, '0', disp);					//set the width of the target address to be 5 instead of 3, as a part of it being an extended instruction
		else
			oss << writeHex (3, '0', disp);					//otherwise, just write the target address to the output string stream object normally

		//we then need to update the registers used for addressing

		//no need to worry about B, that is already taken care of in
		//the Pass 2 method with the "BASE" directive

		//X is the one register we need to update here
		if (mnemonic == "LDX") {
			X = TA;								//store the target address in register X
		}
		else if (mnemonic == "TIX" || mnemonic == "TIXR")
			X++;								//increment X register by 1
		else {}

	}
	else if (format == 2) {
		size_t commaIndex;							//declare a size_t indexing variable to determine if there is a comma
		int r1;									//declare an int variable to store the number of register 1
		int r2;									//declare an int variable to store the number of register 2
		char temp;								//declare a char variable to temporarily store char values
		std::string tempOperand;						//declare a string variable to temporarily store the operand with the index register specifier

		oss << writeHex (2, '0', opcode);					//write the opcode instruction to the output string stream object
		tempOperand = operand + "," + irs;					//concatenate the original operand instruction together and store in the temporary string variable
		commaIndex = tempOperand.find(',');					//search for a comma

		temp = tempOperand.at(0);						//store first register into temp variable (Ex: if operand is "A,X", temp will be 'A')
		r1 = regVals [temp];							//extract the register number value via the regVals map

		//a comma in the operand means there are two registers listed
		if (commaIndex != std::string::npos) {
			temp = tempOperand.at(commaIndex + 1);				//store second register into temp variable
			r2 = regVals [temp];						//extract the register number value via the regVals map
		}
		//otherwise, there is only one register actually being used
		else
			r2 = 0;								//just set the second register to zero

		oss << writeHex (1, '0', r1) << writeHex (1, '0', r2);			//write the value of both registers to the output string stream object

		//figure out the numbers of the registers being used
		//if there is only one register, then the other register is automatically zero (ex: CLEAR)
	}
	//if format == 1
	else
		oss << writeHex (2, '0', opcode);					//write the opcode instruction to the output string stream object, no need to do anything else for format 1 instructions

	return oss.str();								//return the string
}

//write to listing file (pass 2)
void writeListFile (std::ofstream& listfs, std::string loc, std::string label, std::string opcode, std::string operand, char pre1, char pre2, char irs, std::string instr) {
	if (loc != "LTORG") {
		//print out the components accordingly
		listfs << std::left << std::setw(16) << loc << std::setw(16) << label << std::setw(16) << pre1 + opcode << std::setw(24);
		//if the index register specifier is not empty
		if (irs != '\0')
			listfs << pre2 + operand + "," + irs;				//concatenate the irs with the 2nd prefix + operand
		else
			listfs << pre2 + operand;					//otherwise, just print the 2nd prefix + operand
		listfs << instr << std::endl;						//finish the line off with the machine instruction
	}
	//if the line is a LTORG directive statement
	else {
		listfs << std::left << std::setw(32) << " " << loc << std::endl;	//getComponents method ends up assigning LTORG to the location, so we will just handle this exception here as a workaround
	}
}

//second pass algorithm
void secondPass (std::string& intFileName, Optab& optab, std::vector<std::map<std::string, std::string>>& symtab, std::vector<Littab> littab) {

	//declare string variables to store values for the three
	//different types of source statements
	std::string location;								//declare string variable for location
	std::string label;								//declare string variable for label
	std::string opcode;								//declare string variable for operation instruction
	std::string operand;								//declare string variable for operand
	char prefix1;									//declare a prefix variable to store the prefix of the opcode
	char prefix2;									//declare another char variable to store the prefix for the operand
	char irs;									//declare a char variable to store the index register specifier (irs) that an operand may contain (Ex: The "X" in "TABLE,X")

	//declare other variables for pass 2
	int i;										//declare i as a variable used to manually loop through arrays and check how many components are in the statement
	bool hasPrefix;									//declare boolean variable to determine if a symbol has a prefix
	bool hasLiteral;								//might not be needed for this loop
	bool commentLine;								//declare boolean variable to determine if the line is a comment line or not
	bool isInteger;									//declare boolean variable to determine if string value is an int
	bool base;									//declare boolean variable to determine if there is a statement that stores a value in the base register ("BASE")
	int format;									//declare int variable to store the format of the instruction in
	int targetAddr;									//declare int variable to store target address of the operand
	std::string instr;								//delare string variable to store the assembled object code instruction
	//need more variables later on

	//declare register variables to store operand values
	//these following registers are used for addressing
	int X;										//X register, index addressing variable
	int B;										//B register, base-relative addressing variable
	int PC;										//PC register, PC-relative addressing variable

	//initialize optab
	//Optab optab;									//initialize optab class variable
	std::unordered_map<std::string, std::pair<int, int>> OPTAB;			//declare OPTAB hash table variable
	OPTAB = optab.getOptab();							//retrieve optab and store in the declared variable above
	std::unordered_map<std::string, std::pair<int, int>>::iterator opIt;		//declare iterator for optab hash table 

	//declare iterators for symtab and littab
	std::vector<std::map<std::string, std::string>>::iterator symIt;
	std::vector<Littab>::iterator litIt;

	//set up files to read from/write to
	std::istringstream intFiName(intFileName);						//declare a string stream to read the name of files

	std::string noExtension;								//declare a string to read the name of the file into but w/o the extension
	std::string fileName;									//declare another string to concatenate the noExtension variable with the extension of the original souce file
	std::string listingFileName;								//declare another string to concatenate the noExtension variable with the extension of the listing file

	std::getline(intFiName, noExtension, '.');						//call getline method with a space as a delim parameter in order to extract name of the file w/o the " (INT).sic" extension
	fileName = noExtension + ".sic";							//concatenate noExtension with an .sic extension to comprise the name of the original source file
	listingFileName = noExtension + ".I";							//concatenate noExtension with an I extension to comprise the name of the listing file

	std::ifstream intFile(intFileName.c_str());						//open intermediate file to read from

	std::ofstream listFile(listingFileName.c_str());					//create and open listing file to write to

	checkIfFileOpen (intFile, "intermediate file");						//check if intermediate file is open via function
	checkIfFileOpen (listFile, "listing file");						//check if listing file is open via function

	std::cout << "Creating listing file -> \"" << listingFileName << "\"\n" << std::endl;	//display that the listing file is being created

	listFile << ". Listing file for " << fileName << std::endl;				//display the title of the file, no need to put an extra newline this time (intermediate file already took care of that)

	std::cout << "Starting Pass 2\n" << std::endl;						//display that the assembler is about to go through the pass 2 algorithm

	std::cout << "Reading the intermediate file" << std::endl;				//display that the intermediate file is being read

	location = " ";									//initialize location variable
	label = " ";									//initialize label variable
	opcode = " ";									//initialize opcode variable
	operand = " ";									//initialize operand variable
	instr = " ";									//initialize instruction variable
	prefix1 = ' ';									//initialize opcode prefix variable
	prefix2 = ' ';									//initialize operand prefix variable
	irs = '\0';									//initialize index register specifier variable
	commentLine = true;								//initialize commentLine boolean variable to true, assume that each lin eis a comment line until proven otherwise
	base = false;									//initialize base boolean variable to false
	X, B, PC = 0;									//initialize all three addressing register variables to be zero

	//beginning pass 2 logic
	std::string line;								//declare string variable for program to read + process each line from file into
	//while line is a comment line
	while (commentLine) {
		std::getline(intFile, line);						//read the first line from intermediate file
		
		//erase carriage return character from line
		line.erase(std::remove(line.begin(), line.end(), '\n'), line.end());
		line.erase(std::remove(line.begin(), line.end(), '\r'), line.end());

		commentLine = isCommentLine(line);					//check if the line is a comment line
		std::cout << line << std::endl;						//output the line
		getComponents(i, line, location, label, opcode, operand, prefix1);	//call getComponents() for the first line made in this loop that isn't a comment line, though comment lines do not impose a problem on this method
	}

	if (opcode == "START") {
		writeListFile(listFile, location, label, opcode, operand, prefix1, prefix2, irs, instr);	//write to listing file
		getline(intFile, line);										//read the next input line (getline)
		
		//erase carriage return character from line
		line.erase(std::remove(line.begin(), line.end(), '\n'), line.end());
		line.erase(std::remove(line.begin(), line.end(), '\r'), line.end());
		
		commentLine = isCommentLine(line);								//check if line is a comment line
		std::cout << line << std::endl;									//output the line
		getComponents(i, line, location, label, opcode, operand, prefix1);				//call getComponents()
		//std::cout << opcode << std::endl;
	}
	while (opcode != "END") {
		//if not comment line
		if (!commentLine) {
			hasLiteral = checkIfLiteral(operand);					//determine whether the operand is a literal
			isInteger = isAnInteger(operand, prefix2, irs);				//determine whether string value is an int and assign the isInteger variable accordingly
			opIt = OPTAB.find(opcode);						//search optab for opcode again
			//if opcode is found
			if (opIt != OPTAB.end()) {
				format = opIt->second.second;					//obtain the format of the instruction found in optab
				//for format 3 instructions
				if (format == 3) {
					//if the operand exists AND as a non-integer (AKA a symbol)
					if (operand != " " && !isInteger) {
						//search and check if the operand is found in symtab
						//first define a lambda function to determine if label is in the map of the vector-map
						auto hasOperand = [&](const std::map<std::string, std::string>& sym) {
							return sym.find(operand) != sym.end();
						};
						symIt = std::find_if(symtab.begin(), symtab.end(), hasOperand);		//then we can use find_if to search for the operand
						//if the symbol is found
						if (symIt != symtab.end())
							targetAddr = std::stoi(symIt->at(operand), nullptr, 16);	//convert symbol value from string hex representation to integer and store as the operand address
						else if (hasLiteral) {
							Littab literal;							//declare temporary struct literal variable
							
							operand = prefix2 + operand;					//add the prefix back to the literal now so it can run through the getLiteralVals function smoothly
							getLiteralVals (operand, literal.name, literal.type, literal.length, literal.operandVal);	//assign literal values to the temporary variable so we can look for it in the literals vector
							operand = operand.substr(1);					//extract the prefix out of the opcode string variable again so that the writeIntFunction doesn't add an extra prefix
							//note: isAnInteger() function extracted the prefix from the
							//operand string variable, hence why we need to add the prefix
							//back to it temporarily to run it through getLiteralVals()

							//define a lambda function to determine if the name of the given
							//literal is of a literal that is established in the littab
							auto hasLiteral = [&](const Littab& lit) {
								return lit.name == literal.name;
							};
							litIt = std::find_if(littab.begin(), littab.end(), hasLiteral);		//search the literals vector for the given literal w/ find_if and the given lambda value
							if (litIt != littab.end())
								targetAddr = std::stoi(litIt->address, nullptr, 16);		//convert address of literal from string hex representation to integer and store as the operand address
							else {
								std::cerr << "Error: Cannot find literal" << std::endl;		//output error message
								exit(1);							//terminate program with error indicator
							}
						}
						else {
							targetAddr = 0x0;					//store 0 as operand address
							std::cerr << "Error: Undefined symbol" << std::endl;	//output error message (undefined symbol)
							exit(1);						//terminate program with error indicator set
						}
					}
					else {
						//if the operand is nonexistent (Ex: RSUB)
						if (operand == " ")
							targetAddr = 0x0;			//store 0 as operand address
						//if the operand is an int
						else
							targetAddr = std::stoi(operand);	//store the operand as the target address
					}
				}
				//we don't need to do anything for format 2 or 1

				instr = assembleInstruction (optab, opIt, X, B, PC, isInteger, base, location, operand, i, targetAddr, prefix1, prefix2, irs);	//call function to assemble object code instruction
			}
			else if (opcode == "BASE") {
				//search and check if the operand is found in symtab (obvious copy-paste from a bit earlier)
				//first define a lambda function to determine if label is in the map of the vector-map
				auto hasOperand = [&](const std::map<std::string, std::string>& sym) {
					return sym.find(operand) != sym.end();
				};
				symIt = std::find_if(symtab.begin(), symtab.end(), hasOperand);			//then we can use find_if to search for the operand
				//if the symbol is found
				if (symIt != symtab.end()) {
					B = std::stoi(symIt->at(operand), nullptr, 16);				//convert symbol value from string hex representation to integer and store it in the B register addressing variable
					base = true;								//set the base boolean variable to be true, signifying that there is a base register value being set
				}
				else {
					std::cerr << "Error: Undefined symbol" << std::endl;			//output error message (undefined symbol)
					exit(1);								//terminate program with error indicator set
				}
			}
			else if (opcode == "BYTE" || opcode == "WORD") {
				std::ostringstream op;							//declare output string stream object to store operand into
				if (opcode == "WORD") {
					if (isInteger) {
						int numOperand;						//declare temporary int variable to store the int value of the numeric operand

						numOperand = std::stoi(operand);			//convert operand from a string to an int, and store in numOperand
						op << writeHex (6, '0', numOperand);			//write the operand to the output string stream object in hex representation
						instr = op.str();					//store the result as a machine instruction
					}
					else {
						//define a lambda function to determine if label is in the map of the vector-map
						auto hasOperand = [&](const std::map<std::string, std::string>& sym) {
							return sym.find(operand) != sym.end();
						};
						symIt = std::find_if(symtab.begin(), symtab.end(), hasOperand);		//search and check if the operand is found in symtab via find_if
					}
				}
				else if (opcode == "BYTE") {
					char constType;                                                 //declare temporary char variable to store the type of constant (either hex or char)
					size_t start;							//declare a temporary size_t variable to store the start index of a string
					size_t end;							//declare another temporary size_t variable to store the end index
					std::string constant;						//declare a temporary string variable to store the constant itself (ex: C'EOR' => EOF)
					//int length;							//declare a temporary int variable to store the length of the constant found

					start = operand.find("'") + 1;					//find the first single quote, this is where the string of the constant starts
					end = operand.find("'", start);					//find the second single quote, this is where the string of the constant ends

					constant = operand.substr(start, end - start);			//extract the constant with the substr() method, first parameter is the start index, the second parameter is the length of the string hence (end - start)

					constType = operand[0];						//get the constant type (either C or X)
					//length = constant.length();					//get the length of the literal and assign it to the length parameter variable

					//constant is in chars	
					if (constType == 'C') {
						//loop through each char in the constant
						for (char c : constant) {
							int i = (int) c;				//convert char value to int
							op << writeHex (2, '0', i);			//write converted value to output string stream in hex
						}
						instr = op.str();					//convert output string stream object value to string and store as the machine instruction
					}
					//constant is in hex
					else if (constType == 'X') {
						//convert constant to all lower-case
						std::transform(constant.begin(), constant.end(), constant.begin(),
							[](unsigned char c) { return std::tolower(c); });
						instr = constant;					//convert constant to operand value
					}
					else {
						std::cerr << "Error: Invalid constant" << std::endl;	//print out an error message if the constant type is anything other than 'C' or 'X'
						exit(1);						//terminate the function with an error indicator
					}
				}
				//convert constant to object code        
			}
			//literal defining statement
			else if (label == "*") {
				Littab literal;						//declare temporary struct littab variable
				std::string opLowerCase;				//declare temporary string variable to store the operand value in lower case

				opcode = prefix1 + opcode;				//add prefix back to the literal so it can run through the getLiteralVals function
				getLiteralVals (opcode, literal.name, literal.type, literal.length, literal.operandVal);	//get the values of the literal, we just need the operand value here
				opcode = opcode.substr(1);				//extract the prefix from the opcode again

				opLowerCase = literal.operandVal;			//assign the operand value of the literal object to the temprary string variable
				//convert the operand value to lower-case
				std::transform(opLowerCase.begin(), opLowerCase.end(), opLowerCase.begin(),
					[](unsigned char c) { return std::tolower(c); });
				instr = opLowerCase;					//assign the literal operand value as the object code instruction
			}
			else {}
		}
		//if it is a comment line
		else
			listFile << line << std::endl;					//write the comment line to the listing file
		if (!commentLine)
			writeListFile(listFile, location, label, opcode, operand, prefix1, prefix2, irs, instr);	//write to listing file        
		prefix1 = ' ', prefix2 = ' ';										//set both prefix values to null before reading next line
		irs = '\0';												//clear the value of the index register specifier from any previous iterations
		instr.erase();												//erase all contents of the object code instruction stored in the variable from the previous statement
		getline(intFile, line);											//read next input line (getline)

		//erase carriage return character from line
		line.erase(std::remove(line.begin(), line.end(), '\n'), line.end());
		line.erase(std::remove(line.begin(), line.end(), '\r'), line.end());
		
		commentLine = isCommentLine(line);								//check if line is a comment line
		std::cout << line << std::endl;									//output the line
		getComponents(i, line, location, label, opcode, operand, prefix1);				//call getComponents()
	}

	writeListFile(listFile, location, label, opcode, operand, prefix1, prefix2, irs, instr);		//write the end line to the listing file

	//besides the code up till the end line, we also need to go through the
	//declared literals after the end line
	while (std::getline(intFile, line)) {

		//erase carriage return character from line
		line.erase(std::remove(line.begin(), line.end(), '\n'), line.end());
		line.erase(std::remove(line.begin(), line.end(), '\r'), line.end());
		
		//no need to worry about if the line is a comment line at this point
		std::cout << line << std::endl;									//output the line
		getComponents(i, line, location, label, opcode, operand, prefix1);				//call getComponents()

		Littab literal;											//declare temporary struct littab variable
		std::string opLowerCase;									//declare temporary string variable to store the value of the literal in lower case

		opcode = prefix1 + opcode;									//add prefix back to the literal so it can run through the getLiteralVals function
		getLiteralVals (opcode, literal.name, literal.type, literal.length, literal.operandVal);	//get the values of the literal, we just need the operand value here
		opcode = opcode.substr(1);									//extract the prefix from the opcode again
		opLowerCase = literal.operandVal;								//assign the operand value of the literal object to the temporary string variable
		//convert the operand value to lower-case for output
		std::transform(opLowerCase.begin(), opLowerCase.end(), opLowerCase.begin(),
			[](unsigned char c) { return std::tolower(c); });
		instr = opLowerCase;										//assign the literal operand value as the object code instruction

		writeListFile(listFile, location, label, opcode, operand, prefix1, prefix2, irs, instr);	//then write the literal pool line to the listing file
	}

	std::cout << std::endl;											//add an extra newline to the standard output
	std::cout << "Listing File successfully assembled" << std::endl;					//display that the intermediate file has successfully written everything needed to it

	//close intermediate file
	intFile.close();

	//output file closes automatically

	std::cout << "Pass 2 complete\n" << std::endl;					//display that the second pass is complete
}

//first pass algorithm
void firstPass (const std::string& fileName, Optab& optab) {

	const int MAX_LOCATION = 0x100000;						//declare a constant variable for the the maximum memory location that can exist in a SIC/XE program

	//declare string variables to store values for the three
	//different types of source statements
	std::string location;								//declare string variable for location, not actually needed for pass 1 but needed for getComponents method
	std::string label;								//declare string variable for label
	std::string opcode;								//declare string variable for operation instruction (the one that determines the opcode)
	std::string operand;								//declare string variable for the operand
	char prefix;									//declare char variable to store prefix for OPCODE
											//for this pass, we will need to get the string of the mnemonics without prefixes
	//declare other variables for pass one logic
	int i;										//declare i as a variable used to manually loop through arrays and check how many components are in the statement
	bool start;									//declare boolean variable to determine when to start the assembly process, that being the scanner comes across "START"
	bool hasPrefix;									//declare boolean variable to determine if a symbol has a prefix
	bool hasLiteral;								//declare boolean variable to determine if an operand signifies a literal
	bool commentLine;								//declare boolean variable to determine if the line is a comment or blank line
	int startAddr;									//declare int variable for starting address
	int locCtr;									//declare int variable for location counter
	int prevLoc;									//declare int variable to store the previous location
	int tempLoc;									//declare separate int variable from locCtr to store the location for EQU or ORG statements
	int length;									//declare int variable to calculate length of progam (end location - starting address)
	int format;									//declare int variable to get the format of the instruction
	int operandVal;									//declare int variable to convert any int operand values from string to int
	std::string cSect;								//declare string variable for the one control section variable (title of the assembly program)

	//declare optab variables
	std::unordered_map<std::string, std::pair<int, int>> OPTAB;			//declare OPTAB hash table variable
	OPTAB = optab.getOptab();							//retrieve optab and store in the declared variable above
	std::unordered_map<std::string, std::pair<int, int>>::iterator opIt;		//declare iterator for optab hash table

	//declare symtab variables
	std::vector<std::map<std::string, std::string>> symtab;				//declare vector-map for symbol table elements (label, locCtr) so they can be listed in the order they are inserted
	std::vector<std::map<std::string, std::string>>::iterator symIt;		//declare iterator for symtab vector-map
	
	//declare littab variables
	std::vector<Littab> littab;							//declare vector to store literal struct variables
	std::vector<Littab>::iterator litIt;						//declare iterator for the above vector
	std::map<std::string, bool> declaredLits;					//declare a map variable to store the name of each literal and a boolean variable to determine if literal is defined or not
	std::map<std::string, bool>::iterator decLitIt;					//declare iteraror for the above map

	//set up files to read from/write to
	std::istringstream fiName(fileName);						//convert fileName to input stream object for getline commands; this one is for reading the given file name
	
	std::string noExtension;							//establish string variable to contain the name of the source file but without the extension
	std::string intFileName;							//establish string variable to contain the name of the intermediate file
	std::string symTabFileName;							//establish string variable to contain the name of the symbol table file
	std::string litTabFileName;							//establish string variable to contain the name of the literal table file

	std::getline(fiName, noExtension, '.');						//get the name of the current source file, but without the extension, hence the delim parameter ('.')

	intFileName = noExtension + ".int";						//establish name of the intermediate file, store in respective variable
	symTabFileName = noExtension + ".st";						//establish name of the symbol table file, store in respective variable
	//litTabFileName = noExtension + "(lit).st";					//establish name of the literal table file, store in respective variable

	//std::cout << "Intermediate file: " << intFileName << std::endl;		//test if the intermediate files are named accordingly
	//std::cout << "Symbol table file: " << symTabFileName << std::endl;
	//std::cout << "Literal table file: " << litTabFileName << std::endl;

	//open/create files

	//first the source file
	std::ifstream sourceFile(fileName.c_str());					//open the source file to read
	checkIfFileOpen (sourceFile, "source file");					//check if source file is open

	//create other files to write to ONLY if opening source file works
	std::ofstream intFile(intFileName.c_str());					//create and open an intermediate file to write to
        std::ofstream symFile(symTabFileName.c_str());					//create and open a symbol table file to write to
	//std::ofstream litFile(litTabFileName.c_str());				//create and open a literal table file to write to

	//check if the files are open via checkIfOpen () function
	checkIfFileOpen (sourceFile, "source file");
	checkIfFileOpen (intFile, "intermediate file");
	checkIfFileOpen (symFile, "symbol table file");

	std::cout << "Opening up \"" << fileName << "\"\n" << std::endl;		//display that the source file is being opened up

	std::cout << "Creating intermediate file -> \"" << intFileName << "\"" << std::endl;		//display that the intermediate file is being created
	std::cout << "Creating symbol table file -> \"" << symTabFileName << "\"" << std::endl;		//display that the symbol table file is being created
	std::cout << std::endl;

	intFile << ". Intermediate file for " << fileName << "\n" << std::endl;		//display the title of the file
	symFile << ". Symbol Table file for " << fileName << "\n" << std::endl;		//display the title of the file

	commentLine = true;								//initialize commentLine boolean variable to true, assume that each line is a comment line until proven otherwise
	start = false;									//initialize start boolean variable to false
	cSect = " ";									//initialize control section variable
	location = "On Pass 1";								//initialize location variable to signal to getComponents method that this is not needed yet
	label = " ";									//initialize label variable
	opcode = " ";									//initialize opcode variable
	operand = " ";									//initialize operand variable
	prefix = ' ';									//initialize prefix variable

	std::cout << "Starting Pass 1\n" << std::endl;					//display that assembler is about to go through the pass 1 algorithm
	
	std::cout << "Reading the source file" << std::endl;				//display that the source file is being read

	//beginning pass 1 logic
	std::string line;								//declare string to read + process each line in the file
	//while the line is a comment line
	while (commentLine) {
		std::getline(sourceFile, line);						//keep reading through lines until there is a line that isn't a comment or blank line
		
		//erase carriage return character from line
		line.erase(std::remove(line.begin(), line.end(), '\n'), line.end());
		line.erase(std::remove(line.begin(), line.end(), '\r'), line.end());
		
		commentLine = isCommentLine(line);					//check if the line is a comment line
		std::cout << line << std::endl;						//output the line
		getComponents(i, line, location, label, opcode, operand, prefix);	//call method to assign values to components, this is mainly for the first line that is not a comment line
	}

	if (opcode == "START") {
		startAddr = std::stoi(operand);						//use stoi function to convert operand from string to int then store as start address value
		locCtr = startAddr;							//initialize location counter to starting address value
		writeIntFile(locCtr, label, opcode, operand, intFile, prefix);		//call method to write to intermediate file
		cSect = label;								//assign "START" label to cSect variable
		getline(sourceFile, line);						//read next line
		
		//erase carriage return character from line
		line.erase(std::remove(line.begin(), line.end(), '\n'), line.end());
		line.erase(std::remove(line.begin(), line.end(), '\r'), line.end());
		
		commentLine = isCommentLine(line);					//check if line is a comment line
		std::cout << line << std::endl;						//output the line
		getComponents(i, line, location, label, opcode, operand, prefix);	//call method to assign values to components
	}
	else
		locCtr = 0;								//initialize locCtr to 0 if the first non-comment line is not a start directive

	while (opcode != "END")	{
		prevLoc = locCtr;							//assign current value of location counter to the previous value
		//if this is not a comment line
		if (!commentLine) {
			//if there is a symbol in LABEL field (AKA i = 4)
			if (i == 4) {
				//define a lambda function to determine if label is in the symtab map
				auto hasLabel = [&](const std::map<std::string, std::string>& sym) {
					return sym.find(label) != sym.end();
				};
				symIt = std::find_if(symtab.begin(), symtab.end(), hasLabel);	//use find_if function to find the label in symtab, using the established lambda function
				//if the label is already in symtab,
				//something is wrong
				if (symIt != symtab.end()) {
					//print error message showing which label is already established in program
					std::cerr << "Error: Label " << label << " is already found in symtab" << std::endl;
					//list the elements in the symbol table
					std::cerr << "Elements in symtab are: " << std::endl;
					for (symIt = symtab.begin(); symIt != symtab.end(); symIt++) {
						std::map<std::string, std::string>& map = *symIt;
						std::map<std::string, std::string>::iterator mapIt;
						for (mapIt = map.begin(); mapIt != map.end(); mapIt++) {
							std::cerr << std::left << std::setw(12) << mapIt->first << mapIt->second << std::endl;
						}
					}
					exit(1);					//terminate program w/ error indicator
				}
				else {
					std::map<std::string, std::string> tempMap;	//declare map variable to temporarily store symbol table elements in order to append them to the vector-map
					std::ostringstream loc;				//declare output string stream to write string output to
					loc << writeHex (6, '0', locCtr);		//call writeHex function and write location counter to loc
					tempMap[label] = loc.str();			//convert output string stream and its contents to a string and assign it to the tempMap variable
					symtab.push_back(tempMap);			//insert tempMap value (label + current location) into SYMTAB
				}
			}

			hasLiteral = checkIfLiteral(operand);				//call function to check if the operand signifies a literal

			if (hasLiteral) {
				Littab literal;						//declare temporary struct littab element
				getLiteralVals (operand, literal.name, literal.type, literal.length, literal.operandVal);	//call function to get values of the littab element
				decLitIt = declaredLits.find(literal.name);		//search declaredLits map to check if the given literal is already defined
				//if that doesn't hold true
				if (decLitIt == declaredLits.end()) {
					declaredLits [literal.name] = false;		//assign the boolean variable of the declaredLits map element to false by default, signifying that the literal has yet to be declared in the program
					littab.push_back(literal);			//add littab element to the vector of struct variables
				}
			}

			opIt = OPTAB.find(opcode);					//search OPTAB for opcode
			if (opIt != OPTAB.end()) {					//if opcode is found in the opcode table
				format = opIt->second.second;				//assign the format by extracting the second value from the int pair in the hash table 
				locCtr += format;					//increment the location counter by the format number (format 1 = 1, format 2 = 2, format 3 = 3)
			}
			else if (opcode == "WORD") {
				locCtr += 3;						//increment location by 3 as 1 word = 3 bytes
			}
			else if (opcode == "RESW") {					//RESW implies that the operand is an int value
				operandVal = std::stoi(operand);			//use stoi to convert operand from a string to an int
				locCtr += 3 * operandVal;				//increment by the int value multiplied by 3 (1 word = 3 bytes)
			}
			else if (opcode == "RESB") {
				operandVal = std::stoi(operand);			//use stoi for the same reasons as with "RESW"
				locCtr += operandVal;					//increment by just the int value (1 byte each)
			}
			else if (opcode == "BYTE") {
				char constType;							//declare temporary char variable to store the type of constant (either hex or char)
				size_t start;							//declare a temporary size_t variable to store the start index of a string
				size_t end;							//declare another temporary size_t variable to store the end index
				std::string constant;						//declare a temporary string variable to store the constant itself (ex: C'EOR' => EOF)
				int length;							//declare a temporary int variable to store the length of the constant found

				start = operand.find("'") + 1;					//find the first single quote, this is where the string of the constant starts
				end = operand.find("'", start);					//find the second single quote, this is where the string of the constant ends

				constant = operand.substr(start, end - start);			//extract the constant with the substr() method, first parameter is the start index, the second parameter is the length of the string hence (end - start)

				constType = operand[0];						//get the constant type (either C or X)
				length = constant.length();					//get the length of the literal and assign it to the length parameter variable

				if (constType == 'C') {}					//constant is in chars, no need to alter length at all
				else if (constType == 'X')					//constant is in hex
					length /= 2;						//two hex values = 1 byte
				else {
					std::cerr << "Error: Invalid constant" << std::endl;	//print out an error message if the constant type is anything other than 'C' or 'X'
					exit(1);						//terminate the function with an error indicator
				}
				locCtr += length;						//increment the location counter by the found length
			}
			//we don't do anything with "BASE" directive till the next pass
			//this is just here so that "BASE" directive statements do
			//not falsely 'pass through' the else condition of this if-else block
			else if (opcode == "BASE") {}
			else if (opcode == "EQU" || opcode == "ORG") {
				bool isInteger;						//declare boolean variable to determine if string value is an int or not
				char prefix2;						//declare a temporary char value to store any prefix of the operand in, or if nothing else, pass off as a parameter to the isAnInteger method
				char irs;						//declare a temporary char value to store any index register specifier of the operand in, or if nothing else, pass off as a parameter to the isAnInteger method

				isInteger = isAnInteger(operand, prefix2, irs);		//determine if the operand is an integer
				tempLoc = locCtr;					//initialise tempLoc to the value of the current location

				std::ostringstream loc;					//declare an output string stream object to store the location in hex representation

				//if-else block for the operand

				//if the operand is the asterisk sign
				if (operand == "*") {}					//we don't need to change anything here, the symtab algoritm from earlier on has this covered
				//if the operand is an integer
				else if (isInteger)
					tempLoc = std::stoi(operand);			//convert the operand from a string to an int, and store the value in tempLoc
				//if the operand is equal to a symbol
				else {
					char op;					//declare a temporary char variable to store any potential arithmetic operators in the operand (Ex: BUFFEND-BUFFER)
					size_t opInd;					//declare a temporary size_t variable to store the index of the potential arithmetic operator in operand
					//check if it's just one symbol or
					//an arithmetic operation with a symbol

					//if there is a +, -, * or / char in
					//the string, then we know it's an arithmetic
					//operation

					op = checkForOperator (operand, opInd);		//check if there is an aritmetic operator in the operand

					//if an arithmetic operator exists
					if (op != '\0') {
						std::string sym1, sym2;					//declare string variables to store both symbols
						int val1, val2, total;					//declare int variables to store the value of both symbols + the total (depending on the arithmetic operator)

						//this also means there are two
						//different symbols in the operand
						sym1 = operand.substr(0, opInd);			//extract the value of the first symbol
						sym2 = operand.substr(opInd + 1);			//extract the value of the second symbol

						isInteger = isAnInteger(sym1, prefix2, irs);		//determine if sym1 is a constant int value, prefix2 and irs are just placeholder parameters and aren't needed for anything here

						//define a lambda function to determine if first symbol is in symtab
						auto hasSym1 = [&](const std::map<std::string, std::string>& s1) {
							return s1.find(sym1) != s1.end();
						};
						symIt = std::find_if(symtab.begin(), symtab.end(), hasSym1);				//search symtab for the first symbol
						//if symbol is found in symtab
						if (symIt != symtab.end())
							val1 = std::stoi(symIt->at(sym1), nullptr, 16);					//convert the found value from string hex representation to an int, and store it in val1
						//if first symbol is a constant int
						else if (isInteger)
							val1 = std::stoi(sym1);								//convert sym1 directly from a string to an int and store it in val1
						else {
							std::cerr << "Error: " << sym1 << " not found" << std::endl;			//output an error message (symbol not found)
							exit(1);									//terminate the program with an error indicator set
						}

						isInteger = isAnInteger(sym2, prefix2, irs);		//determine if sym2 is a constant int value, prefix2 and irs are just placeholder parameters and aren't needed for anything here

						//define another lambda function but w/ the second symbol
						auto hasSym2 = [&](const std::map<std::string, std::string>& s2) {
							return s2.find(sym2) != s2.end();
						};
						symIt = std::find_if(symtab.begin(), symtab.end(), hasSym2);				//search symtab for the second symbol
						//if symbol is found in symtab
						if (symIt != symtab.end())
							val2 = std::stoi(symIt->at(sym2), nullptr, 16);					//convert the found value from string hex representation to an int, and store it in val2
						//if second symbol is a constant int
						else if (isInteger)
							val2 = std::stoi(sym2);								//convert sym1 directly from a string to an int and store it in val2
						else {
							std::cerr << "Error: " << sym2 << " not found" << std::endl;			//output an error message (symbol not found)
							exit(1);									//terminate the program with an error indicator set
						}

						if (op == '+')
							total = val1 + val2;		//add the value of both symbols together
						else if (op == '-')
							total = val1 - val2;		//subtract the value of both symbols
						else if (op == '*')
							total = val1 * val2;		//multiply the value of both symbols
						//if operator is '/'
						else
							total = val1 / val2;		//divice the value of both symbols

						//check if the given total is positive
						if (total >= 0)
							tempLoc = total;		//store the total as the new value of tempLoc
						else {
							std::cerr << "Error: Negative location (" << total << ") obtained by \"";
							std::cerr << operand << "\". " << "Locations cannot be negative" << std::endl;	//output an error message (negative location)
							exit(1);									//terminate the program with an error indicator
						}
					}
					//if operand is just one symbol, so it's just the value of one symbol being stored in another
					else {
						int location;				//declare a temporary int variable to store the int value of the given location

						//define a lambda function to determine if operand is in symtab
						auto hasSym = [&](const std::map<std::string, std::string>& s) {
							return s.find(operand) != s.end();
						};
						symIt = std::find_if(symtab.begin(), symtab.end(), hasSym);				//use result of lambda function and find_if to search for the operand
						if (symIt != symtab.end())
							location = std::stoi(symIt->at(operand), nullptr, 16);				//convert the found value from string hex representation to an int, and store it in location
						else {
							std::cerr << "Error: Symbol in EQU operand must be established" << std::endl;	//output an error message (symbol not found)
							exit(1);									//terminate the program with an error indicator set
						}

						tempLoc = location;						//assign tempLoc with the newly given value of the location
					}
				}

				//now we will take care of the difference between EQU and ORG directive
				if (opcode == "EQU") { 
					//with EQU, we need to also update the value of the label
					loc << writeHex (6, '0', tempLoc);					//write the value of the tempLoc to the output string stream object

					//define a lambda function to determine if label is in symtab
					auto hasLabel = [&](const std::map<std::string, std::string>& sym) {
						return sym.find(label) != sym.end();
					};
					symIt = std::find_if(symtab.begin(), symtab.end(), hasLabel);		//use lambda function result and find_if to retrieve the label of the symtab element, so we can update it
					symIt->at(label) = loc.str();						//update the location of the symbol with the tempLoc value written to the output string stream object
				}
				//if opcode == "ORG"
				else {
					//since there is no label, we don't need to worry about updating that
					//we just need to update the locCtr to be the same value as tempLoc
					locCtr = tempLoc;
				}

				writeIntFile(tempLoc, label, opcode, operand, intFile, prefix);			//write the line to the intermediate file, but this time with the temporary location
			}
			else if (opcode == "LTORG") {
				//only do something if there is actually a literal
				//being applied earlier on in the program
				if (!littab.empty()) {
					//note: some of this is copy-paste from another
					//part towards the end of pass 1 method
					bool alreadyDeclared;							//create a boolean variable to determine whether a vector still needs to be declared
					std::string tempOp;							//create a temporary string variable to store the opcode value, we will need to maintain the original opcode value for later

					litIt = littab.end() - 1;						//find the location of the most recently added literal and store as the value in the littab iterator
					decLitIt = declaredLits.find(litIt->name);				//search the declaredLits string & boolean map for the name of the literal that was found
					alreadyDeclared = decLitIt->second;					//extract the boolean value out of the declaredLits map variable
					if (!alreadyDeclared) {
						writeIntFile(locCtr, label, opcode, operand, intFile, prefix);	//write the recent instruction to the int

						std::string lit;						//declare a temporary string variable to convert literal type char variable to a string so we can concatenate it to another string variable

						//establish the label, opcode, operand and prefix
						//so we can call the writeIntFile function with them
						label = "*";							//the label of the defining statement is an asterisk
						lit = litIt->type;						//convert literal type from a char to a string and store it to the temporary string variable
						tempOp = lit + "'" + litIt->name + "'";				//assign the name of the literal to the opcode variable
						operand = " ";							//operand is blank
						prefix = '=';							//prefix is the equal sign, in fact that is the prefix for literals in general
						writeIntFile(locCtr, label, tempOp, operand, intFile, prefix);	//write statemetn defining the literal to the intermediate file
						//if the address of the literal has not been established yet
						if (litIt->address.empty()) {
							std::ostringstream loc;					//declare temporary output string stream object to extract the location of the literal

							loc << writeHex (0, '0', locCtr);			//write the location to the output string stream object
							litIt->address = loc.str();				//update the literal by establishing its address value
						}
						locCtr += litIt->length;					//increment location counter by length of literal
						declaredLits[litIt->name] = true;				//update boolean value of the declared literals map variable to true, signifying it is now declared
					}
					//if the literal is already declared
					else {
						std::cerr << "Error: LTORG is redundant. " << litIt->name;
						std::cerr << " is already defined" << std::endl;		//print an error message
						exit(1);							//terminate the program with an error indicator
					}
				}
			}
			//if the statement is defining a literal
			else if (label == "*") {
				Littab literal;											//declare temporary struct littab variable
				std::ostringstream loc;										//declare temporary output string stream object to extract the location value

				loc << writeHex (0, '0', locCtr);								//write the location to the output string stream object
				opcode = prefix + opcode;									//add the prefix back to the literal now so it can run through the getLiteralVals function smoothly
				getLiteralVals (opcode, literal.name, literal.type, literal.length, literal.operandVal);	//assign literal values to the struct littab variable so we know what to look for in the literals vector
				opcode = opcode.substr(1);									//extract the prefix out of the opcode string variable again so that the writeIntFunction doesn't add an extra prefix
				litIt = std::find(littab.begin(), littab.end(), literal);					//search the literals vector for the given literal
				//if there is a literal already established in the literals vector
				if (litIt != littab.end()) {
					litIt->address = loc.str();								//convert the contents of the output stream string object to a string value and use it to update the address of the literal
					declaredLits [litIt->name] = true;							//update the boolean flag of the declaredLits map element to true, so we know we do not have to declare the literal at the end of the program
					locCtr += litIt->length;								//increment the location counter by the length of the literal
				}
				//if there isn't a literal found in the literals vector
				//this means the literal is being defined before being used
				else {
					literal.address = loc.str();						//do pretty much the same thing as if there is a literal found in the literals vector
					declaredLits [literal.name] = true;					//except without the iterator value and with the littab struct variable instead
					locCtr += literal.length;						//though this time, instead of updating the boolean flag of declaredLits, we are establishing the variable with the flag being set to true
					littab.push_back(literal);						//add littab element to the vector of struct variables
				}
			}
			else {
				std::cerr << "Error: Invalid operation code" << std::endl;			//print out error message
				std::cerr << "\"" << opcode << "\" is not an instruction" << std::endl;		//showcase which opcode value is is invalid
				exit(1);									//terminate the program, non-zero int argument indicating an error
			}

			//if the prefix of the opcode is a plus sign
			//signifying an extended instruction
			if (prefix == '+')
				locCtr += 1;									//increment the location counter by 1 more byte
		}
		else
			intFile << line << std::endl;								//write comment line to intermediate file

		//if the memory location exceeds 1 megabyte (0x100000 in hex)
		if (locCtr > MAX_LOCATION) {
			std::cerr << "Error: Program out of bounds" << std::endl;				//output error message (out of bounds)
			std::cerr << "Maximum memory in SIC/XE machine is a megabyte" << std::endl;		//remind the user the maximum amount of bytes that can be used here
			exit(1);										//terminate the program with an error indicator
		}

		//we don't write components of a comment line to the intermediate file
		//and the writeIntFile function is already taken care of with these three symbol-defining directives
		if (!commentLine && opcode != "ORG" && opcode != "EQU" && opcode != "LTORG") {
			//note: prevLoc is being used instead of locCtr since locCtr is
			//actually being calculated for the next line rather than the current
			writeIntFile(prevLoc, label, opcode, operand, intFile, prefix);		//write the line to the intermediate file
		}
		getline(sourceFile, line);							//read the next line

		//erase carriage return character from line
		line.erase(std::remove(line.begin(), line.end(), '\n'), line.end());
		line.erase(std::remove(line.begin(), line.end(), '\r'), line.end());

		commentLine = isCommentLine(line);						//check if line is a comment line
		std::cout << line << std::endl;							//output the line
		getComponents(i, line, location, label, opcode, operand, prefix);		//call method to assign values to components
	}

	std::cout << std::endl;								//add an extra endline

	writeIntFile(locCtr, label, opcode, operand, intFile, prefix);			//write the END line to the intermediate file

	//function to write the rest of the literals to the file
	for (litIt = littab.begin(); litIt != littab.end(); litIt++) {
		bool alreadyDeclared;							//create a boolean variable to determine whether a vector still needs to be declared

		decLitIt = declaredLits.find(litIt->name);				//search the declaredLits string & boolean map for the current literal being looped through in the literals vector
		alreadyDeclared = decLitIt->second;					//extract the boolean value out of the declaredLits map variable
		//if the literal is NOT already defined
		if (!alreadyDeclared) {
			std::string lit;						//declare a temporary string variable to convert literal type char variable to a string so we can concatenate it to another string variable
			//establish the label, opcode, operand and prefix
			//so we can call the writeIntFile function with them
			label = "*";							//the label of the defining statement is an asterisk
			lit = litIt->type;						//convert literal type from a char to a string and store it to the temprary string variable
			opcode = lit + "'" + litIt->name + "'";				//assign the name of the literal to the opcode variable
			operand = " ";							//operand is blank
			prefix = '=';							//prefix is the equal sign, in fact that is the prefix for literals in general
			writeIntFile(locCtr, label, opcode, operand, intFile, prefix);	//write statement defining the literal to the intermediate file
			//if the address of the literal has not been established yet
			if (litIt->address.empty()) {
				std::ostringstream loc;					//declare temporary output string stream object to extract the location of the literal

				loc << writeHex (0, '0', locCtr);			//write the location to the output string stream object
				litIt->address = loc.str();				//update the literal by establishing its address value
			}
			locCtr += litIt->length;					//increment location counter by length of literal
			declaredLits[litIt->name] = true;				//update boolean value of the declared literals map variable to true, signifying it is now declared
		}
	}

	std::cout << "Intermediate file successfully assembled" << std::endl;		//display that the intermediate file has successfully written everything needed to it

	length = locCtr - startAddr;							//calculate the length through subtracting the end address by the start location

	//write symtab elements to symtab file
	writeSymTabFile (symtab, symFile, cSect, length, startAddr);			//call method to write the symbol table to the symtab file 
	std::cout << "Symbol Table file successfully assembled" << std::endl;		//display that the symbol table file has successfully written everything needed to it

	symFile << std::endl;								//include an extra line-space in the symtab file to set up for writing the literal table into it

	//write littab elements to littab file
	writeLitTabFile (littab, symFile);						//call method to write the literal table to the symtab file
	std::cout << "Literal Table file successfully assembled" << std::endl;		//display that the literal table has been successfully written to the symtab file

	std::cout << std::endl;								//insert an extra newline

	//close input file
	sourceFile.close();

	//output file closes automatically

	std::cout << "Pass 1 complete\n" << std::endl;					//display that the first pass is complete

	secondPass (intFileName, optab, symtab, littab);				//call the second pass method with the intermediate file
}

int main (int argc, char* argv[]) {
	
	const int MIN_ARGS = 2;								//establish the expected number of command-line arguments
	const int NUM_FILES = argc - 1;							//establish the number of files put in command-line argument; subtract 1 because of first command-line argument
	
	std::string fileNames[NUM_FILES];						//declare a string array to store the names of each file entered via command-line argument
	std::string programName;							//declare string variable to store first command-line argument into

	Optab optab;									//declare Optab class variable and build the operation code table, declared here so table only needs to be built once

	//loop through fileNames array and assign fileNames to each array location
	for (int i = 0; i < argc - 1; i++)
		fileNames[i] = argv[i + 1];						//starts from argv[1] instead of argv[0]

	programName = "asxe";								//assign the name of program ("asxe") into string variable

	//check if there are at least two command-line arguments
	if (argc < MIN_ARGS) {
		std::cerr << "Please enter at least two command-line arguments ";
		std::cerr << "(<program name> + at least 1 sic file)" << std::endl;	//output error message if there are less than two command-line arguments
		exit(1);								//terminate program with error indicator
	}

	std::cout << "Running " << programName << std::endl;				//display that this program is running
	std::cout << "Number of XE source files: " << NUM_FILES << "\n" << std::endl;	//output the number of files entered based on the command-line arguments
	
	//create loop to read files through a method call
	for (int i = 0; i < argc - 1; i ++)
		firstPass(fileNames[i], optab);						//call the Pass 1 algorithm for the file

	std::cout << programName << " finished\n" << std::endl;				//display that the program is finished

	return 0;
}
