//Class: CS530 - Systems Programming (Spring 2024)
//Assignment: Project #2 (SIC/XE Two-Pass Assembler)
//Filename: optab.cpp (implementation source file)

#include "optab.h"
#include <iostream>
#include <string>
#include <unordered_map>
#include <utility>
#include <algorithm>
#include <iomanip>

//define constructor - initialize opcode table here
Optab::Optab () {

	//format 1 instructions
	optab ["FIX"] = std::make_pair (0xC4, 1);
	optab ["FLOAT"] = std::make_pair (0xC0, 1);
	optab ["HIO"] = std::make_pair (0xF4, 1);
	optab ["NORM"] = std::make_pair (0xC8, 1);
	optab ["SIO"] = std::make_pair (0xF0, 1);

	//format 2 instructions
	optab ["ADDR"] = std::make_pair (0x90, 2);
	optab ["CLEAR"] = std::make_pair (0xB4, 2);
	optab ["COMPR"] = std::make_pair (0xA0, 2);
	optab ["DIVR"] = std::make_pair (0x9C, 2);
	optab ["MULR"] = std::make_pair (0x98, 2);
	optab ["RMO"] = std::make_pair (0xAC, 2);		//the hex value is AC, does RMO also cool you down?
	optab ["SHIFTL"] = std::make_pair (0xA4, 2);
	optab ["SHIFTR"] = std::make_pair (0xA8, 2);
	optab ["SUBR"] = std::make_pair (0x94, 2);
	optab ["SVC"] = std::make_pair (0xB0, 2);
	optab ["TIXR"] = std::make_pair (0xB8, 2);

	//format 3/4 instructions
	optab ["ADD"] = std::make_pair (0x18, 3);
	optab ["ADDF"] = std::make_pair (0x58, 3);
	optab ["AND"] = std::make_pair (0x40, 3);
	optab ["COMP"] = std::make_pair (0x28, 3);
	optab ["COMPF"] = std::make_pair (0x88, 3);
	optab ["DIV"] = std::make_pair (0x24, 3);
	optab ["DIVF"] = std::make_pair (0x64, 3);
	optab ["J"] = std::make_pair (0x3C, 3);
	optab ["JEQ"] = std::make_pair (0x30, 3);
	optab ["JGT"] = std::make_pair (0x34, 3);
	optab ["JLT"] = std::make_pair (0x38, 3);
	optab ["JSUB"] = std::make_pair (0x48, 3);
	optab ["LDA"] = std::make_pair (0x00, 3);
	optab ["LDB"] = std::make_pair (0x68, 3);
	optab ["LDCH"] = std::make_pair (0x50, 3);
	optab ["LDF"] = std::make_pair (0x70, 3);
	optab ["LDL"] = std::make_pair (0x08, 3);
	optab ["LDS"] = std::make_pair (0x6C, 3);
	optab ["LDT"] = std::make_pair (0x74, 3);
	optab ["LDX"] = std::make_pair (0x04, 3);
	optab ["LPS"] = std::make_pair (0xD0, 3);
	optab ["MUL"] = std::make_pair (0x20, 3);
	optab ["MULF"] = std::make_pair (0x60, 3);
	optab ["OR"] = std::make_pair (0x44, 3);
	optab ["RD"] = std::make_pair (0xD8, 3);
	optab ["RSUB"] = std::make_pair (0x4C, 3);
	optab ["SSK"] = std::make_pair (0xEC, 3);
	optab ["STA"] = std::make_pair (0x0C, 3);
	optab ["STB"] = std::make_pair (0x78, 3);
	optab ["STCH"] = std::make_pair (0x54, 3);
	optab ["STF"] = std::make_pair (0x80, 3);
	optab ["STI"] = std::make_pair (0xD4, 3);
	optab ["STL"] = std::make_pair (0x14, 3);
	optab ["STS"] = std::make_pair (0x7C, 3);
	optab ["STSW"] = std::make_pair (0xE8, 3);
	optab ["STT"] = std::make_pair (0x84, 3);
	optab ["STX"] = std::make_pair (0x10, 3);
	optab ["SUB"] = std::make_pair (0x1C, 3);
	optab ["SUBF"] = std::make_pair (0x5C, 3);
	optab ["TD"] = std::make_pair (0xE0, 3);
	optab ["TIX"] = std::make_pair (0x2C, 3);
	optab ["WD"] = std::make_pair (0xDC, 3);
}

//print out operation code table; JUST FOR TESTING
void Optab::printOptab () {
	const int size = optab.size();

	std::cout << "Mnemonic\t" << "Opcode\t" << "Format" << std::endl;

	for (const auto& op : optab) {
		std::cout << op.first << "\t\t";
		std::cout << std::setw(2) << std::setfill('0') << std::right << std::hex << op.second.first;
		std::cout << resetiosflags(std::ios_base::basefield) << "\t" << op.second.second << std::endl;
	}
	std::cout << std::resetiosflags(std::ios_base::basefield);
}

//print out the hex opcode for the given instruction
void Optab::printOpcode (const std::string& mnemonic) {
	std::unordered_map<std::string, std::pair<int, int>>::iterator it;		//declare an iterator to retrieve the given key of the element in optab

	it = optab.find(mnemonic);
	if (it != optab.end()) {
		std::cout << std::setw(2) << std::setfill('0') << std::right;
		std::cout << std::hex << it->second.first << std::endl;
		std::cout << resetiosflags(std::ios_base::basefield);
	}
	else {
		std::cerr << "Error: Unknown instruction" << std::endl;
	}
}

//retrieve optab to store it in a variable
std::unordered_map<std::string, std::pair<int, int>> Optab::getOptab() const {
	return optab;
}

//TESTING
//int main () {
//	Optab optab;
//	std::unordered_map<std::string, std::pair<int, int>> OPTAB;
//	OPTAB = optab.getOptab();
//	const int HEX = 0xFF;
//	//std::map<std::string, int>::iterator it;
//	
//	optab.printOptab();	//solely for testing purposes
//	//optab.printOpcode("STS");
//	std::cout << "Format for TIX is " << OPTAB ["TIX"].second << std::endl;
//	//std::cout << "Format for FIX is " << optab.getFormat("FIX") << std::endl;
//	//std::cout << "Format for ADDR is " << optab.getFormat("ADDR") << std::endl;
//	//std::cout << "Format for MULR is " << optab.getFormat("MULR") << std::endl;
//	std::cout << HEX << std::endl;
//}
